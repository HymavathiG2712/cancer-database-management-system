-- MySQL dump 10.13  Distrib 8.0.31, for macos12 (x86_64)
--
-- Host: localhost    Database: dbmsproject
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cancer_gene`
--

DROP TABLE IF EXISTS `cancer_gene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cancer_gene` (
  `gene_id` varchar(20) NOT NULL,
  `cancer_id` varchar(20) NOT NULL,
  `cancer_type` varchar(30) NOT NULL,
  `gene_type` varchar(25) NOT NULL,
  `gene_name` varchar(20) NOT NULL,
  PRIMARY KEY (`gene_id`),
  KEY `cancer_id_idx` (`cancer_id`),
  KEY `cancergene_id_idx` (`cancer_id`),
  CONSTRAINT `cancergene_id` FOREIGN KEY (`cancer_id`) REFERENCES `cancer_details` (`cancer_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancer_gene`
--

LOCK TABLES `cancer_gene` WRITE;
/*!40000 ALTER TABLE `cancer_gene` DISABLE KEYS */;
INSERT INTO `cancer_gene` VALUES ('G001','C001','Brain and Other Nervous System','Oncogene','EGFR, PDGFRA, BRAF'),('G002','C002','Breast','Tumor Suppressor','BRCA1, BRCA2, TP53'),('G003','C003','Cervix Uteri','Oncogene,Tumor Suppressor','HPV, TP53, PTEN'),('G004','C004','Colon and Rectum','Oncogene,Tumor Suppressor','APC, KRAS, TP53'),('G005','C005','Corpus Uteri','Oncogene,Tumor Suppressor','PTEN, PIK3CA, CTNNB1'),('G006','C006','Esophagus','Oncogene,Tumor Suppressor','TP53, EGFR, KRAS'),('G007','C007','Gallbladder','Tumor Suppressor','TP53, SMAD4, ARID1A'),('G008','C008','Kidney and Renal Pelvis','Oncogene,Tumor Suppressor','VHL, TP53, PTEN'),('G009','C009','Larynx','Oncogene,Tumor Suppressor','TP53, EGFR, PTEN'),('G010','C010','Leukemias','Oncogene,Tumor Suppressor','BCRABL1, FLT3, IDH1'),('G011','C011','Liver','Tumor Suppressor','TP53, CTNNB1, TERT'),('G012','C012','Lung and Bronchus','Oncogene,Tumor Suppressor','EGFR, KRAS, TP53'),('G013','C013','Melanoma of the Skin','Oncogene,Tumor Suppressor','BRAF, NRAS, TP53'),('G014','C014','Myeloma','Oncogene,Tumor Suppressor','KRAS, NRAS, TP53'),('G015','C015','Non-Hodgkin Lymphoma','Oncogene,Tumor Suppressor','BCL2, MYC, TP53'),('G016','C016','Oral Cavity and Pharynx','Oncogene,Tumor Suppressor','TP53, EGFR, KRAS'),('G017','C017','Ovary','Oncogene,Tumor Suppressor','TP53, BRAF, KRAS'),('G018','C018','Pancreas','Oncogene,Tumor Suppressor','KRAS, TP53, CDKN2A'),('G019','C019','Prostate','Oncogene,Tumor Suppressor','TP53, PTEN, AR'),('G020','C020','Stomach','Oncogene,Tumor Suppressor','TP53, PIK3CA, CDH1'),('G021','C021','Thyroid','Oncogene,Tumor Suppressor','BRAF, RET, RAS'),('G022','C022','Urinary Bladder','Oncogene,Tumor Suppressor','TP53, FGFR3, HRAS');
/*!40000 ALTER TABLE `cancer_gene` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-01 18:29:47
